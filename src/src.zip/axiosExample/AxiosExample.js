import React, {useEffect, useState} from 'react';
import axios from "axios";
import {Group, GroupsResponse} from "../classes/Group";

const axiosInstance = axios.create({
    baseURL: "http://django.local/api/v1"
});
const AxiosExample = () => {

    const [groupsResponse, setGroupsResponse] = useState(new GroupsResponse());

    useEffect(() => {
        const getGroups = async () => {
            try {
                await axiosInstance.get("groups/", {params: {format: "json"}})
                    .then(response => {
                        const groupsData = response.data;
                        const parsedGroups = groupsData.results.map(groupData => new Group(
                            groupData.id,
                            groupData.objectSid,
                            groupData.distinguishedName,
                            groupData.description,
                            groupData.whenCreated,
                            groupData.securityDescriptor,
                            groupData.genericAll,
                            groupData.writeDacl
                        ));
                        const groupsResponse = new GroupsResponse(
                            this.count = groupsData.count,
                            this.next = groupsData.next,
                            this.previous = groupsData.previous,
                            this.groupList = parsedGroups
                        );
                        setGroupsResponse(groupsResponse);
                        console.log(groupsResponse);
                    });
            } catch (e) {
                console.log(e);
            }
        }
        getGroups();
    }, []);

    return (
        <div>
            <ul>
                <li> nesimi yüklüyor</li>
                {groupsResponse && groupsResponse.groupList && groupsResponse.groupList.length > 0 ? (
                    groupsResponse.groupList.map(group => (
                        <li key={group.id}>{group.distinguishedName}</li>
                    ))
                ) : (
                    <li>Loading...</li>
                )}
            </ul>
        </div>
    );
};
export default AxiosExample;
